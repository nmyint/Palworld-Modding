@{

# ============================================================
# Module Information
# ============================================================

RootModule = 'PalworldModding.psm1'

ModuleVersion = '0.2.0'

GUID = 'YOUR-GUID-HERE'

Author = 'Noel Myint'

CompanyName = ''

Copyright = '(c) Noel Myint'

Description = 'Palworld Modding Workshop PowerShell Module'

PowerShellVersion = '7.0'

# ============================================================
# Functions
# ============================================================

FunctionsToExport = @(

    # Core
    'Initialize-PwWorkshop',
    'Get-PwContext',
    'Reset-PwContext',

    # Configuration
    'Get-PwWorkshopConfig',
    'Save-PwWorkshopConfig',
    'Test-PwWorkshopConfig',

    # Workshop
    'Get-PwVersion',
    'Get-PwWorkshopInfo',

    # Environment
    'Test-PwEnvironment',

    # Paths
    'Get-PwPaths',

    # Deployment
    'Get-PwDeployment',

    # Tools
    'Get-PwTool',
    'Get-PwTools'

)

CmdletsToExport = @()

VariablesToExport = '*'

AliasesToExport = @()

# ============================================================
# Private Data
# ============================================================

PrivateData = @{

    PSData = @{

        Tags = @(
            'Palworld'
            'Workshop'
            'Modding'
            'PowerShell'
        )

        ProjectUri = 'https://github.com/nmyint/Palworld-Modding'

        LicenseUri = ''

        ReleaseNotes = 'Sprint 2 Complete'

    }

}

}
